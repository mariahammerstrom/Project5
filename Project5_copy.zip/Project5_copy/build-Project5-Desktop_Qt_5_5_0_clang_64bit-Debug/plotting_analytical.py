"""
A program that plots the position x(t) and velocity v(t) as a function of time for a box on a spring
solved with 4th order Runge-Kutta (RK4) and Velocity-Verlet (VV), compared with the analytical solution.
"""

import sys
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.pyplot import rc
rc('font',**{'family':'serif'})

 
def read_file(filename):
    # Input: filename for file with structure [t,mass,x,vx]
    # Output: arrays of data values
    
    data = np.loadtxt(filename,unpack=True) # Read data
    
    t = data[0]            # time
    x = data[1]            # position,x-direction
    vx = data[2]          # velocity, x-direction
    Fx = data[3]
    
    return t,x,vx,Fx
    

def plot_time(time_step,N):
    # Function that plots the results from VV and RK4 as a function of time, 
    # compared with the analytical solution.
    # Input: time step and number of integration points, N.
    
    # Get data
    filename_verlet_3D = '../build-Project5-Desktop_Qt_5_5_0_clang_64bit-Debug/analytic_VV_%d_%.2f.txt' % (N,time_step)
    filename_verlet = '../build-Project5-Desktop_Qt_5_5_0_clang_64bit-Debug/Verlet_analytic_%.3f.txt' % (time_step)
    filename_VV = '../build-Project5-Desktop_Qt_5_5_0_clang_64bit-Debug/VV_analytic_%.3f.txt' % (time_step)
    filename_RK4 = '../build-Project5-Desktop_Qt_5_5_0_clang_64bit-Debug/analytic_RK4_%d_%.2f.txt' % (N,time_step)

    tV,xV,vxV,FxV = read_file(filename_verlet)
    tVV,xVV,vxVV,FxVV = read_file(filename_VV)
    tVV3,xVV3,vxVV3,FxVV3 = read_file(filename_verlet_3D)
    tRK4,xRK4,vxRK4,FxRK4 = read_file(filename_RK4)
    
    # Calculate energies
    E_verlet = 0.5*np.array(vxV)**2 + 0.5*np.array(xV)**2
    E_RK4 = 0.5*np.array(vxRK4)**2 + 0.5*np.array(xRK4)**2
    E_VV = 0.5*np.array(vxVV)**2 + 0.5*np.array(xVV)**2
    E_VV3 = 0.5*np.array(vxVV3)**2 + 0.5*np.array(xVV3)**2
    E_analytic = 0.5*np.array(-np.sin(tVV))**2 + 0.5*np.array(np.cos(tVV))**2
    
    # Make plots
    # POSITION
    plt.figure(1)
    plt.title('Comparing methods (position), time step = %.2f' % time_step,size=12)
    #plt.plot(tV,np.cos(tV),label='Analytic')
    #plt.plot(tV,xV,label='Verlet')
    #plt.plot(tVV,xVV,label='VV')
    plt.plot(tVV3,xVV3,label='VV-3D')
    plt.plot(tVV3,np.cos(tVV3),label='Analytic-3D')
    plt.plot(tRK4,xRK4,label='RK4')
    plt.xlabel(r'$t$',size=14)
    plt.ylabel(r'$x$',size=14)
    plt.legend(loc=1,prop={'size':12})
    plt.show()
    
    #"""
    # VELOCITY
    plt.figure(2)
    plt.title('Comparing methods (velocity), time step = %.2f' % time_step,size=12)
    #plt.plot(tV,-np.sin(tV),label='Analytic')
    #plt.plot(tV,vxV,label='Verlet')
    #plt.plot(tVV,vxVV,label='VV')
    plt.plot(tVV3,vxVV3,label='VV-3D')
    plt.plot(tVV3,-np.sin(tVV3),label='Analytic-3D')
    plt.plot(tRK4,vxRK4,label='RK4')
    plt.xlabel(r'$t$',size=14)
    plt.ylabel(r'$v_x$',size=14)
    plt.legend(loc=2,prop={'size':12})
    plt.show()
    #"""
    
    """
    # ENERGY
    plt.figure(3)
    plt.title('Total energy, time step = %.2f' % time_step,size=12)
    plt.plot(tVV,np.array(E_analytic)-0.5,label='Analytic')
    plt.plot(tV,np.array(E_verlet)-0.5,label='Verlet')
    #plt.plot(tVV,np.array(E_VV)-0.5,label='VV')
    plt.plot(tVV3,np.array(E_VV3)-0.5,label='VV3')
    #plt.plot(t_RK4,np.array(E_RK4)-0.5,label='RK4')
    plt.xlabel(r'$t$',size=14)
    plt.ylabel(r'$E$',size=14)
    plt.legend(loc=1,prop={'size':12})
    plt.show()
    """
    
    """
    # FORCE
    plt.figure(4)
    plt.title('Comparing methods (forces), time step = %.2f' % time_step,size=12)
    #plt.plot(tV,FxV,label='Verlet')
    #plt.plot(tVV,FxVV,label='VV')
    plt.plot(tVV3,FxVV3,label='VV-3D')
    plt.plot(tVV3,-np.cos(tVV3),label='Analytic-3D')
    plt.plot(tRK4,FxRK4,label='RK4')
    plt.xlabel(r'$t$',size=14)
    plt.ylabel(r'$F_x$',size=14)
    plt.legend(loc=2,prop={'size':12})
    plt.show()
    """
    
    return


def main(argv):
    # Plot results as a function of time
    time_step = 0.1
    integration_points = 100
    plot_time(time_step,integration_points)
    
	
if __name__ == "__main__":
    main(sys.argv[1:]) 