#include "solver.h"
#include <cmath>
#include "star.h"
#include "galaxy.h"
#include <fstream>
#include <iostream>

solver::solver()
{

}

void solver::RK4(int dimension,int N, double final_time,star &star1,star star2,std::ofstream &file,bool &stellar){
    // 4th order Runge-Kutta solver for two coupeled ODE in "dimension" dimensions

    double k1[dimension],k2[dimension],k3[dimension],k4[dimension]; // position
    double l1[dimension],l2[dimension],l3[dimension],l4[dimension]; // velocity

    double Fg; // gravitational force between the two objects
    double h = final_time/((double) N); // time step

    for(int i=0;i<N;i++){
        if(stellar) Fg = star1.GravitationalForce_r3(star2);
        else Fg = 1;

        for(int j=0;j<dimension;j++){
            k1[j] = h*star1.velocity[j];
            l1[j] = -h*Fg*star1.position[j]; // h*dvdt(x[j],mass1,mass2);
        }
        for(int j=0;j<dimension;j++){
            k2[j] = h*(star1.velocity[j]+l1[j]/2.);
            l2[j] = -h*Fg*(star1.position[j]+k1[j]/2.); // h*dvdt(x[j]+k1[j]/2.,mass1,mass2);
        }
        for(int j=0;j<dimension;j++){
            k3[j] = h*(star1.velocity[j]+l2[j]/2.);
            l3[j] = -h*Fg*(star1.position[j]+k2[j]/2.); // h*dvdt(x[j]+k2[j]/2.,mass1,mass2);
        }
        for(int j=0;j<dimension;j++){
            k4[j] = h*(star1.velocity[j]+l3[j]);
            l4[j] = -h*Fg*(star1.position[j]+k3[j]); // h*dvdt(x[j]+k3[j],mass1,mass2);
        }

        // Update new position and velocity, write to file
        file << i*h << "\t";
        for(int j=0;j<dimension;j++){
            star1.position[j] += (k1[j] + 2.*(k2[j] + k3[j]) + k4[j])/6.;
            star1.velocity[j] += (l1[j] + 2.*(l2[j] + l3[j]) + l4[j])/6.;
            file << star1.position[j] << "\t" << star1.velocity[j] << "\t";
        }
        file << std::endl;
    }
}


void solver::Verlet(int dimension,int N,double final_time,star &star1,star star2,std::ofstream &file,bool &stellar){
    // Velocity-Verlet solver for two coupeled ODEs in "dimension" dimensions

    double h = final_time/((double) N); // time step
    double x[dimension*N];              // position
    double v[dimension*N];              // velocity

    double relative_position;

    for(int j=0;j<dimension;j++){
        x[j] = star1.position[j];       // initial position
        v[j] = star1.velocity[j];       // initial velocity
        x[j+dimension] = x[j] + v[j]*h; // Euler guess
    }

    double Fg; // gravitational force between the two objects
    double time = 0.0;

    file << time << "\t"; // write time to file
    // Write to file
    for(int j=0;j<dimension;j++){
        file << x[j] << "\t" << v[j] << "\t" << Fg*0.0;}
    file << std::endl;

    // Loop over time
    for(int i=1; i<N; i+=1){

        file << i*h << "\t"; // write time to file

        if(stellar) Fg = star1.GravitationalForce_r3(star2);
        else Fg = 1;

        // Loop over dimensions
        for(int j=0;j<dimension;j++){
            star1.position[j] = x[j+i*dimension];
            relative_position = star2.position[j] - star1.position[j];

            x[j+(i+1)*dimension] = 2*star1.position[j] - x[j+(i-1)*dimension] + h*h*Fg*relative_position;
            v[j+i*dimension] = (x[j+(i+1)*dimension] - x[j+(i-1)*dimension])/(2*h);
        }
        // Write to file
        for(int j=0;j<dimension;j++){
            file << x[j+i*dimension] << "\t" << v[j+i*dimension] << "\t" << Fg*relative_position;}
        file << std::endl;
    }

    // Save final position and velocity
    for(int j=0;j<dimension;j++){
        star1.position[j] = x[dimension*N-(dimension-j)];
        star1.velocity[j] = v[dimension*N-(dimension-j)];
    }
}

void solver::VV(int dimension,int N,double final_time,star &star1,star star2,std::ofstream &file,bool &stellar){
    // Velocity-Verlet solver for two coupeled ODEs in "dimension" dimensions

    double h = final_time/((double) N); // time step
    double v_half[3];
    double time = 0.0;

    double relative_position1,relative_position2;
    double Fg1,Fg2; // gravitational force between the two objects

    // Loop over time
    for(int i=1; i<N; i+=1){

        std::cout << star1.position[0] << "\t" << star1.velocity[0] << std::endl;

        // Write to file
        file << i*h-h << "\t";
        for(int j=0;j<dimension;j++){
            file << star1.position[j] << "\t" << star1.velocity[j] << "\t" << Fg1*relative_position1;}
        file << std::endl;

        if(stellar) Fg1 = star1.GravitationalForce_r3(star2);
        else Fg1 = 1;

        // Calculate new position
        for(int j=0;j<dimension;j++){
            relative_position1 = star2.position[j] - star1.position[j];
            star1.position[j] = star1.position[j] + star1.velocity[j]*h + 0.5*h*h*Fg1*relative_position1;
            v_half[j] = star1.velocity[j] + 0.5*h*Fg1*relative_position1;
        }

        // Calculate new force
        if(stellar) Fg2 = star1.GravitationalForce_r3(star2);
        else Fg2 = 1;

        // Calculate new velocity
        for(int j=0;j<dimension;j++){
            relative_position2 = star2.position[j] - star1.position[j];
            star1.velocity[j] = v_half[j] + 0.5*h*Fg2*relative_position2;
        }
    }
}
